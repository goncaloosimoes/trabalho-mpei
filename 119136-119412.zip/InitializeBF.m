function BF = InitializeBF(n)
% returns BF as an array of length n with all falses
    BF = false(1,n);
end